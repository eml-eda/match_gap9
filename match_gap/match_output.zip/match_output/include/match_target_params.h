#ifndef _MATCH_TARGET_PARAMS_H
#define _MATCH_TARGET_PARAMS_H

#define NUM_MEMORY_LEVELS 3

typedef enum{
    l2_mem,
    l1_mem,
    mem_computation
}memories_list;

typedef enum{
    conv2d_bnorm_requant
    ,dense_bnorm_requant
    ,conv2d_sparse_bnorm_requant
    ,depthwise_conv2d_less_4
    ,conv2d
    ,depthwise_conv2d
    ,conv2d_sparse
    ,elemwise_add
    ,dense
    ,conv2d_bias_add
    ,pointwise_conv2d
    ,add_requant
    ,conv2d_bias_add_requant
    ,dense_bias_add_requant
    ,dense_out
}patterns_list;


#endif