#include <stdio.h>
#include <stdint.h>
#include "tvmgen_default.h"
#include <tvm_runtime.h>
#include <malloc_wrapper.h>
#include <gdb_anchor.h>
#define MAX_PRINT_ERRORS 128
#define STOP_AT_FIRST_ERROR 0
int abs(int v) {return v * ((v > 0) - (v < 0)); }
int main(int argc, char** argv) {
  gap9_cluster_init();

  uint32_t output_size = 2048;
  uint8_t *output = (uint8_t*)malloc_wrapper(output_size * sizeof(uint8_t));
  struct tvmgen_default_outputs outputs = { .output = output, };
  
  uint32_t input_0_size = 2048;
  uint8_t *input_0 = (uint8_t*)malloc_wrapper(input_0_size * sizeof(uint8_t));
  // Fill input with 1
  for (uint32_t i = 0; i < input_0_size; i++){
    input_0[i] = 1;
  }

  struct tvmgen_default_inputs inputs = {
    .input_0 = input_0
  };

  int32_t status = 0;
  printf("\n{");
  printf("\"kernel_cycles\":[0");
  status = tvmgen_default_run(&inputs, &outputs);
  int errors=0;
  printf("\"num_errors\":%d,",errors);
  if(!errors) printf("\"correct\":true,");
  else  printf("\"correct\":false,");
  printf("\"output\":[");
  //for(int k=0;k<output_size;k++) {printf("%d",(uint8_t)output[k]);if(k!=output_size-1) printf(", ");}
  printf("]");
  printf("}\n");
  free_wrapper(input_0);
  free_wrapper(output);
  gap9_cluster_close();
  if(status != 0){
    abort();
  }
  return 0;
}
